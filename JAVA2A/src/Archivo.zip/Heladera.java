
public class Heladera {
	protected Freezer f ;
	
	public Heladera() {
		f = new Freezer();
	}
	
	Freezer getFreezer() {
		return this.f;
	}
	
	
}
