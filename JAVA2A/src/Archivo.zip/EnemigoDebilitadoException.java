
public class EnemigoDebilitadoException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public EnemigoDebilitadoException() {
		super();
	}
	public EnemigoDebilitadoException(String message) {
		super(message);
	}
}
