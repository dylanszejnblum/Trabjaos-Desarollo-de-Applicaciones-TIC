
public class EnemigoDeLaTierra {
	
	public int vida=200;
	
	public void restarVida(int n){
		this.vida -= n;
	}

}
