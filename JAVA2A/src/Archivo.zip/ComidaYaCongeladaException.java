
public class ComidaYaCongeladaException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	public ComidaYaCongeladaException() {
		super();
	}
	public ComidaYaCongeladaException(String message) {
		super(message);
	}
}
