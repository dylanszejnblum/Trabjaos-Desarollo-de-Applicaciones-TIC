package paquete;

public class Celda {

}
