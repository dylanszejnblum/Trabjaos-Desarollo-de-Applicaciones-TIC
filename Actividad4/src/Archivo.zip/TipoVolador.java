
public interface TipoVolador {
	double pv1 = 10;
	double pv2 = 5;
	public  void ataqueDeAla(Pokemon poke);
	public  void tornado(Pokemon poke);
	
}
