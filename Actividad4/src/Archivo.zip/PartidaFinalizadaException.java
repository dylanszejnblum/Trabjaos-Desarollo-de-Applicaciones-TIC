
public class PartidaFinalizadaException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public PartidaFinalizadaException() {
		super();
	}
	public PartidaFinalizadaException(String message) {
		super(message);
	}

}
