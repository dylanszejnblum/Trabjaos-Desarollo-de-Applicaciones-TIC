
public interface TipoFuego {
	
	double p1 = 20;
	double p2 = 50;
	public  void llamarada(Pokemon poke);
	public  void sofoco(Pokemon poke);
}
