
public interface TipoHielo{
	double ph1 = 15;
	double ph2 = 50;
	public void rayoHielo(Pokemon poke) ;
	public void ventisca(Pokemon poke);
}
