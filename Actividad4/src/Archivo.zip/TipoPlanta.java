
public interface TipoPlanta {
	double pp1 = 20;
	double pp2 = 35;
	public  void latigoCepa(Pokemon poke);
	public  void hojaAguda(Pokemon poke);
	
}
