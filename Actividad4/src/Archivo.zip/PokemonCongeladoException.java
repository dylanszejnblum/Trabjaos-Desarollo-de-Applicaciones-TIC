
public class PokemonCongeladoException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public PokemonCongeladoException() {
		super();
	}
	public PokemonCongeladoException(String message) {
		super(message);
	}
	}
