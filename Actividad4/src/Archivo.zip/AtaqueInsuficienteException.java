
public class AtaqueInsuficienteException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AtaqueInsuficienteException() {
		super();
	}
	public AtaqueInsuficienteException(String message) {
		super(message);
	}
	}
