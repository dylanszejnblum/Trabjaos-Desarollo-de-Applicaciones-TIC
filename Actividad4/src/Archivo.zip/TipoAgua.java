
public interface TipoAgua {
	double pa1 = 15;
	double pa2 = 30;
	public  void surf(Pokemon poke);
	public  void hidrobomba(Pokemon poke);
}
