
public class PokemonNoSalvajeException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public PokemonNoSalvajeException() {
		super();
	}
	public PokemonNoSalvajeException(String message) {
		super(message);
	}
	}


